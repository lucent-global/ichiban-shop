<?php
$distinfo = array(
'ed7ebf8eb2030e70186246b4af39ce987d617561' => MODULE_REALDIR . 'mdl_db_import/config.tpl',
'41c746b65bf6466dbb021eb1cbb5598b0ee906a7' => MODULE_REALDIR . 'mdl_db_import/LC_Page_Mdl_Upload_Cyber.php',
'23c5313bc2072a845bb64f23f98293c863a49cfc' => MODULE_REALDIR . 'mdl_db_import/config.php',
);
